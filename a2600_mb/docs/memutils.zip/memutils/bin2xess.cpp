/*
 * bin2xess.cpp
 * ------------
 * Converts a binary file to the XESS-32 format so you can download it into off-chip memory.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

// number of bytes to place per row of the hex file
// Should be a multiple of 4 just to be safe.
#define MAX_FROW	16

#define DEFAULT_LITTLE_ENDIAN 1
#define DEFAULT_SAMPLE_SIZE 1
#define DEFAULT_INIT_ADDRESS 0

void Help();
void ConvertBin(FILE *pBinFile, FILE *pXessFile, unsigned int LESize, unsigned long a,
				char littleEndian);
void ToBigEndian(unsigned char *pBin, unsigned int len, unsigned int LESize);

int main(int argc, char* argv[])
{
	FILE *pBinFile, *pXessFile;
	char LESize, littleEndian;
	unsigned long a;
	int arg;

	// parse command-line arguments
	// see the usage guide to find out what they all mean
	if (argc == 1 || argc > 10) {
		Help();
		return -1;
	}
	LESize = DEFAULT_SAMPLE_SIZE;
	littleEndian = DEFAULT_LITTLE_ENDIAN;
	a = DEFAULT_INIT_ADDRESS;
	pBinFile = pXessFile = 0;
	arg = 1;
	while (arg < argc) {
		if (strcmp(argv[arg],"-i")==0) {
			pBinFile = fopen(argv[++arg], "rb");
			if (!pBinFile) 
			{
				fprintf(stderr, "Cannot open binary file %s for reading.\n", argv[arg]);
				Help();
				return -1;
			}					
		}
		else if (strcmp(argv[arg], "-o")==0) {
			pXessFile = fopen(argv[++arg], "wb");
			if (!pXessFile) 
			{
				fprintf(stderr, "Cannot open XESS-32 file %s for writing.\n", argv[++arg]);
				Help();
				return -1;
			}
		}
		else if (strcmp(argv[arg], "-b")==0) {
			littleEndian = 0;
			LESize = 1;
		}
		else if (strcmp(argv[arg], "-s")==0) {
			LESize = atoi(argv[++arg]);
			if (LESize != 1 && LESize != 2 && LESize != 4) {
				fprintf(stderr, "Sorry, only sizes of 1, 2 or 4 are allowed.\n");
				return -1;
			}
		}
		else if (strcmp(argv[arg], "-a")==0) {
			a = atoi(argv[++arg]);
		}
		else
		{
			fprintf(stderr, "Unrecognized flag %s\n", argv[arg]);
			Help();
			return -1;
		}
		++arg;
	}
	if (pBinFile == 0 || pXessFile == 0) {
		fprintf(stderr, "You must specify input and output files.\n");
		Help();
		return -1;
	}
	ConvertBin(pBinFile, pXessFile, LESize, a, littleEndian);
	printf("yeah!\n");
	// Close files.
	fclose(pXessFile);
	fclose(pBinFile);
	return 0;
}

// display usage information
void Help()
{
	printf("Usage: bin2xess.exe [-s [<sample size>]] [-b] [-a [<initial address>] [-i [<binary file>]] [-o [<XESS-32 file>]]\n");
}

void ConvertBin(FILE *pBinFile, FILE *pXessFile, unsigned int LESize, unsigned long a,
				char littleEndian)
{
	unsigned long address;
	long i, bytesRead;
	unsigned char *pBin;
	address = a;

	pBin = new unsigned char[MAX_FROW];
	// Convert the file row-by-row.
	while ((bytesRead = fread(pBin, 1, MAX_FROW, pBinFile)) != 0)
	{
		// If this is the last row and the number of bytes in the row is odd,
		// add a zero at the end to make the number of bytes even.  We do this because
		// GXSLOAD wants the number of bytes to be even when it downloads data to the 2-byte
		// wide SDRAM.
		if (bytesRead%2 == 1) {
			pBin[bytesRead] = 0;
			bytesRead++;
		}
		// Convert the data to Big Endian, since that is the format GXSLOAD wants.
		if (littleEndian) ToBigEndian(pBin, bytesRead, LESize);
		// Print the header information
		fprintf(pXessFile, "+ %.2x %.8x ", bytesRead, address);
		// Print the data in the row
		for (i = 0; i < bytesRead; i++)
		{
			fprintf(pXessFile, "%.2x ", pBin[i]);
		}
		// End the line
		fprintf(pXessFile, "\r\n");
		address += (unsigned short) bytesRead;
	}
	delete pBin;
}

// change the endian-ness of the data in pBin
void ToBigEndian(unsigned char *pBin, unsigned int len, unsigned int LESize)
{
	unsigned int i;
	unsigned char temp;

	if (LESize == 1) return;
	if ((len % LESize) != 0) {
		fprintf(stderr, "Error: Length of array of binary data is not a multiple of %d\n", LESize);
		fprintf(stderr, "I'm not going to put up with that!\n");
		return;
	}
	for (i = 0; i < len; i+=LESize) {
		switch (LESize) {
		case 2:
			temp = pBin[i];
			pBin[i] = pBin[i+1];
			pBin[i+1] = temp;
			break;
		case 4:
			temp = pBin[i];
			pBin[i] = pBin[i+3];
			pBin[i+3] = temp;
			temp = pBin[i+1];
			pBin[i+1] = pBin[i+2];
			pBin[i+2] = temp;
			break;
		default:
			fprintf(stderr, "I expected a LESize of 2 or 4, not %d.\n", LESize);
			return;
		}
	}
}