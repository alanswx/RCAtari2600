/*
 * bmp2coe.cpp
 * ------------
 * Converts a Windows bitmap to the COE format so you can use it to initialize CORE Gen memory.
 * This code came from my bitmap to HEX converter, so it has some unnecessary baggage that I
 * never removed.
 */

#include <stdio.h>
#include <math.h>
#include <string.h>
// be sure to include this file!
#include "..\bmp.h"

// number of bytes to place per row...this is just a relic from the bitmap to hex converter
#define MAX_FROW	255

#define MIN(x,y)	((x < y) ? (x) : (y))

void Help();
void ReadFileHeader(BITMAPFILEHEADER *pBmfh, FILE *pBMPFile);
void ReadInfoHeader(BITMAPINFOHEADER *pBmih, FILE *pBMPFile);
void ConvertRGB(FILE *pBMPFile, FILE *pCoeFile, BITMAPINFOHEADER *pBmih, unsigned char bFlipped);

// pixel color structure
typedef struct _bgr_
{
	unsigned char blue;
	unsigned char green;
	unsigned char red;
} bgr_type;

int main(int argc, char* argv[])
{
	FILE *pBMPFile, *pCoeFile;
	BITMAPFILEHEADER bmfh;
	BITMAPINFOHEADER bmih;
	unsigned char bFlipped;

	if (argc != 3 && argc != 4)
	{
		Help();
		return -1;
	}
	// Open the files.
	pCoeFile = fopen(argv[--argc], "wb");
	if (!pCoeFile) 
	{
		printf("Cannot open %s for writing.\n", argv[argc]);
		return -1;
	}
	pBMPFile = fopen(argv[--argc], "rb");
	if (!pBMPFile) 
	{
		printf("Cannot open %s for reading.\n", argv[argc]);
		return -1;
	}
	if (argc == 2 && strcmp(argv[--argc], "-f") == 0)
	{
		bFlipped = 1;
	}
	else
	{
		bFlipped = 0;
	}
	// Read the bitmap headers.
	ReadFileHeader(&bmfh, pBMPFile);
	ReadInfoHeader(&bmih, pBMPFile);
	switch (bmih.biCompression)
	{
	case BI_RGB:
		if (bmih.biBitCount == 24)
		{
			ConvertRGB(pBMPFile, pCoeFile, &bmih, bFlipped);
			break;
		}
		else
		{
			printf("Sorry, this program requires that the bit count be 24.\n");
			return -1;
		}
	case BI_RLE8:
	case BI_RLE4:
		printf("Sorry, this program does not work with compressed bitmaps.\n");
		return -1;
	default:
		printf("What kind of compression is this?\n");
		return -1;
	}
	printf("yeah!\n");
	// Close files.
	fclose(pCoeFile);
	fclose(pBMPFile);
	return 0;
}

void Help()
{
	printf("bmp2coe.exe: converts Windows bitmap files into the hex format so we can store it in on-chip RAM.\n");
	printf("syntax: bmp2coe [-f/-u] <BMP file name> <COE file name>\n");
	printf("-f/-u (optional): flipped or upright (default is upright)\n");
	printf("Right now the bitmap must be in uncompressed 24-bit RGB format.\n");
}

/*
 * Read the bitmap file header.
 */
void ReadFileHeader(BITMAPFILEHEADER *pBmfh, FILE *pBMPFile)
{
	fread(&pBmfh->bfType, sizeof(pBmfh->bfType), 1, pBMPFile);
	fread(&pBmfh->bfSize, sizeof(pBmfh->bfSize), 1, pBMPFile);
	fread(&pBmfh->bfReserved1, sizeof(pBmfh->bfReserved1), 1, pBMPFile);
	fread(&pBmfh->bfReserved2, sizeof(pBmfh->bfReserved2), 1, pBMPFile);
	fread(&pBmfh->bfOffBits, sizeof(pBmfh->bfOffBits), 1, pBMPFile);	
}

/*
 * Read the bitmap information header.
 */
void ReadInfoHeader(BITMAPINFOHEADER *pBmih, FILE *pBMPFile)
{
	fread(&pBmih->biSize, sizeof(pBmih->biSize), 1, pBMPFile);
	fread(&pBmih->biWidth, sizeof(pBmih->biWidth), 1, pBMPFile);
	fread(&pBmih->biHeight, sizeof(pBmih->biHeight), 1, pBMPFile);
	fread(&pBmih->biPlanes, sizeof(pBmih->biPlanes), 1, pBMPFile);
	fread(&pBmih->biBitCount, sizeof(pBmih->biBitCount), 1, pBMPFile);
	fread(&pBmih->biCompression, sizeof(pBmih->biCompression), 1, pBMPFile);
	fread(&pBmih->biSizeImage, sizeof(pBmih->biSizeImage), 1, pBMPFile);
	fread(&pBmih->biXPelsPerMeter, sizeof(pBmih->biXPelsPerMeter), 1, pBMPFile);
	fread(&pBmih->biYPelsPerMeter, sizeof(pBmih->biYPelsPerMeter), 1, pBMPFile);
	fread(&pBmih->biClrUsed, sizeof(pBmih->biClrUsed), 1, pBMPFile);
	fread(&pBmih->biClrImportant, sizeof(pBmih->biClrImportant), 1, pBMPFile);
}

void ConvertRGB(FILE *pBMPFile, FILE *pCoeFile, BITMAPINFOHEADER *pBmih, unsigned char bFlipped)
{
	unsigned short address;
	long i, j, bytesRead, pixelsExpected, bytesExpected;
	long rowWidth;
	long bytesInRow, rowSize;
	unsigned char code;
	bgr_type *pBitmap;
	address = 0;
	unsigned char *pJunk;

	/* Sometimes the bit files has extra bytes at the end of the row.  We read them into
	   pJunk and ignore them.*/
	rowWidth = pBmih->biSizeImage/pBmih->biHeight;
	if (rowWidth > 3*pBmih->biWidth)
		pJunk = new unsigned char[rowWidth - 3*pBmih->biWidth];
	else
		pJunk = NULL;
	pixelsExpected = pBmih->biWidth * pBmih->biHeight;
	bytesExpected = 3 * pixelsExpected;
	pBitmap = new bgr_type[pixelsExpected];
	bytesRead = 0;
	for (i = 0; i < (long) pBmih->biSizeImage; i += rowWidth)
	{
		bytesRead += 3*fread(pBitmap + bytesRead/3, 3, pBmih->biWidth, pBMPFile);
		if (pJunk) fread(pJunk, 1, rowWidth - 3*pBmih->biWidth, pBMPFile);
	}
	int error = ferror(pBMPFile);
	if (bytesRead != (long) bytesExpected)
	{
		printf("Failed to read expected number of pixels.  Please contact customer support.\n");
		printf("expected %d on %d and %d\n", bytesExpected, pBmih->biWidth, pBmih->biHeight);
		printf("read %d\n", bytesRead);
		return;
	}
	// Write the header.
	fprintf(pCoeFile, "MEMORY_INITIALIZATION_RADIX=16;\r\n");
	fprintf(pCoeFile, "MEMORY_INITIALIZATION_VECTOR=");
	if (bFlipped)
	{
		for (i = 0; i < pixelsExpected; i += pBmih->biWidth)
		{
			bytesInRow = 0;
			while (bytesInRow < pBmih->biWidth)
			{
				rowSize = MIN(MAX_FROW, pBmih->biWidth - bytesInRow);
				for (j = 0; j < rowSize; j++)
				{
					code = (pBitmap[i+j].red << 4) + (pBitmap[i+j].green << 2) + pBitmap[i+j].blue;
					fprintf(pCoeFile, "\r\n%.2x,",code);
				}
				bytesInRow += rowSize;
				address += (unsigned short) rowSize;
			}
		}
		ungetc(',', pCoeFile);
		fprintf(pCoeFile, ";\r\n");
	}
	else // upright
	{
		for (i = pixelsExpected - pBmih->biWidth; i >= 0; i-= pBmih->biWidth)
		{
			bytesInRow = 0;
			while (bytesInRow < pBmih->biWidth)
			{
				rowSize = MIN(MAX_FROW, pBmih->biWidth - bytesInRow);
				for (j = bytesInRow; j < bytesInRow + rowSize; j ++)
				{
					code = ((pBitmap[i+j].red/0x40) << 4) + ((pBitmap[i+j].green/0x40) << 2)
						+ (pBitmap[i+j].blue/0x40);
					if (address == 0 && j == 0)
						fprintf(pCoeFile, "\r\n%.2x", code);
					else
						fprintf(pCoeFile, ",\r\n%.2x", code);
				}
				bytesInRow += rowSize;
				address += (unsigned short) rowSize;
			}
		}
		fprintf(pCoeFile, ";\r\n");

	}
	delete pBitmap;
}