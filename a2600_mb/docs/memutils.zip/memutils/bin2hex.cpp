/*
 * bmp2hex.cpp
 * -----------
 * Converts a binary file to the HEX format so you can download it into off-chip memory.
 */
#include <stdio.h>
#include <math.h>
#include <string.h>

// number of bytes to place per row of the hex file
#define MAX_FROW	255
// macro for finding the minimum of two values
#define MIN(x,y)	((x < y) ? (x) : (y))

void Help();
void ConvertBin(FILE *pBinFile, FILE *pHexFile);

int main(int argc, char* argv[])
{
	FILE *pBinFile, *pHexFile;

	if (argc != 3)
	{
		Help();
		return -1;
	}
	// Open the files.
	pHexFile = fopen(argv[--argc], "wb");
	if (!pHexFile) 
	{
		printf("Cannot open %s for writing.\n", argv[argc]);
		return -1;
	}
	pBinFile = fopen(argv[--argc], "rb");
	if (!pBinFile) 
	{
		printf("Cannot open %s for reading.\n", argv[argc]);
		return -1;
	}
	ConvertBin(pBinFile, pHexFile);
	printf("yeah!\n");
	// Close files.
	fclose(pHexFile);
	fclose(pBinFile);
	return 0;
}

// help message if user uses incorrect command-line syntax
void Help()
{
	printf("bin2hex: converts a binary data file into the hex format so we can store it in RAM.\n");
	printf("syntax: bin2hex <binary file name> <HEX file name>\n");
}

void ConvertBin(FILE *pBinFile, FILE *pHexFile)
{
	unsigned short address;
	long i, bytesRead;
	unsigned char *pBin;
	unsigned char checksum;
	address = 0;

	pBin = new unsigned char[MAX_FROW];
	// Read and write all the rows of data.
	while ((bytesRead = fread(pBin, 1, MAX_FROW, pBinFile)) != 0)
	{
		// initialize the checksum
		checksum = bytesRead + ((char) (address >> 8)) + ((char) (address & 0x00FF));
		// display the bytes in the row and the base address
		fprintf(pHexFile, ":%.2x%.4x00", bytesRead, address);
		// write out all the bytes in the file
		for (i = 0; i < bytesRead; i++)
		{
			checksum += pBin[i];
			fprintf(pHexFile, "%.2x", pBin[i]);
		}
		// compute and display the checksum
		checksum = 0xFF - checksum + 1;
		fprintf(pHexFile, "%.2x\r\n", checksum);
		address += (unsigned short) bytesRead;
	}
	delete pBin;
	// checksum = 2's complement of sum of high two bytes of address and low two bytes of address
	// and 1 (EOF byte) = 0xFF - (address high + address low + 1) + 1 =
	// 0xFF - (address high + address low)
	checksum = 0xFF - (((char) (address >> 8)) + ((char) (address & 0x00FF)));
	fprintf(pHexFile, ":00%.4x01%.2x\r\n", address, checksum);
}