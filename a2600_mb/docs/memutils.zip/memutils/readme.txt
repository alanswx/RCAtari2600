Here are some simple command line programs for converting binary files and bitmaps to COE, XESS-32, and HEX formats.  If the conversion you're interested in isn't here, you should be able to create it fairly easily from the existing code.  We used these in an introductory digital design course to place files in memory: the XS-40 SRAM, the XSA-100 SDRAM, and the CORE Gen memory macros.  We used the binary converters on RC4 ciphertext, MIDI files, arbitrary waveforms, game-playing algorithms, raw audio signals, etc.; and the bitmap converts on color pictures in VGA-based video games.   We used the HEX format on our old XS-40 boards, then switched to XESS-32 on the XSA-100.

Obviously, these programs and their code are free in every sense of the word.  I hope someone will find them useful.

- Lee Kenyon
lakenyon@stanford.edu

bin2coe.exe
-----------
bin2coe.exe converts a binary file to the COE format.  CORE Gen uses COE files to initialize the contents of memory components.

Usage:
bin2coe [-n <bits per sample>] [-b] [-i <binary file name>] [-o <COE file name>]

-n <bits per sample> specifies the memory width; i.e., the number of bits per memory location
-b specifies that the data is in the Big Endian format; the absence of the -b flag indicates the the data in in the Little Endian format.
-i <binary file name> specifies the name of the binary file which you want to convert to a COE file
-o <COE file name> specifies the name of the COE file that bin2coe.exe creates

bmp2coe.cpp
-----------
bmp2coe.cpp converts a Windows bitmap to a COE file that you can use to initialize a CORE Gen memory macro.  Some important things to keep in mind:
(1) The bitmap must be an uncompressed 24-bit bitmap.
(2) bmp2coe rounds each of the 8-bit color values down to 2 bits to be compatible wit the XESS VGA interface.
(3) The first address in the COE file will contain the upper left pixel of the bitmap; the second address in the COE file will contain the next pixel in the top row, immediately to the righ of the first pixel...and so on.  This isn't the same way the pixels are stored in the bitmap file.

Usage:
bmp2coe [-f/-u] <BMP file name> <COE file name>
-f causes the image to be flipped.  This feature is here just because the bitmap is stored flipped.
-u causes the image to be upright.  (default)
<BMP file name> is the name of the bitmap file to be converted
<COE file name> is the name of the COE file that bmp2coe will create

bin2xess.exe
------------
bin2xess.exe converts a binary file to the XES format, one of the formats that GXSLOAD supports.  The file size is unlimited. (i.e., 2^32 bytes, which is much larger than you would need)

Usage:
bin2xess.exe [-s [<sample size>]] [-b] [-a [<initial address>] [-i [<binary file>]] [-o [<XESS-32 file>]]

-s [<sample size>] memory width; i.e., number of bytes per memory location
-b specifies that the data is in the Big Endian format; the absence of the -b flag indicates the the data in in the Little Endian format.
-a [<initial address>] the address (in decimal) of the first byte within the XESS-32 file.  Since the XESS-32 format is byte-addressable, this should be a byte address, even if you are downloading to the 2-byte SDRAM.  For example, to start a file at SDRAM address 64, the -a flag should be 128.
-i [<binary file>] the name of the binary file that you want to convert to XESS-32
-o [<XESS-32 file>] the name of the XESS-32 file that bin2xess will create



bin2hex.exe
-----------
bin2hex.exe converts a binary file to the HEX format, one of the formats that GXSLOAD supports.  This program only supports HEX files of less than 64K, since that's all that GXSLOAD supported when I wrote it.

Usage:
bin2hex <binary file name> <HEX file name>

bmp2hex.cpp
-----------
bmp2hex converts a Windows bitmap to a HEX file that you can use to initialize external memory.  Note that it would be very easy to make an XESS-32 converter out of this program - or a converter for any other memory format.
(1) The bitmap must be an uncompressed 24-bit bitmap.
(2) bmp2coe rounds each of the 8-bit color values down to 2 bits to be compatible wit the XESS VGA interface.
(3) The first address in the COE file will contain the upper left pixel of the bitmap; the second address in the COE file will contain the next pixel in the top row, immediately to the righ of the first pixel...and so on.  This isn't the same way the pixels are stored in the bitmap file.
(4) This program only supports HEX files of less than 64K, since that's all that GXSLOAD supported when I wrote it.  Change the code to support another memory format if this is a problem. 

Usage
-----
bmp2hex [-f/-u] <BMP file name> <HEX file name>
-f causes the image to be flipped.  This feature is here just because the bitmap is stored flipped.
-u causes the image to be upright.  (default)
<BMP file name> is the name of the bitmap file to be converted
<HEX file name> is the name of the HEX file that bmp2coe will create


