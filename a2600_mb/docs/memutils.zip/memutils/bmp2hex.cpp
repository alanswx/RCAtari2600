/*
 * bmp2hex.cpp
 * -----------
 * Converts a Windows bitmap to the HEX format so you can use it to initialize external memory.
 */

#include <stdio.h>
#include <math.h>
#include <string.h>
#include "bmp.h"

// number of bytes to place per row of the hex file
#define MAX_FROW	255

#define MIN(x,y)	((x < y) ? (x) : (y))

void Help();
void ReadFileHeader(BITMAPFILEHEADER *pBmfh, FILE *pBMPFile);
void ReadInfoHeader(BITMAPINFOHEADER *pBmih, FILE *pBMPFile);
void ConvertRGB(FILE *pBMPFile, FILE *pHexFile, BITMAPINFOHEADER *pBmih, unsigned char bFlipped);

typedef struct _bgr_
{
	unsigned char blue;
	unsigned char green;
	unsigned char red;
} bgr_type;

int main(int argc, char* argv[])
{
	FILE *pBMPFile, *pHexFile;
	BITMAPFILEHEADER bmfh;
	BITMAPINFOHEADER bmih;
	unsigned char bFlipped;

	if (argc != 3 && argc != 4)
	{
		Help();
		return -1;
	}
	// Open the files.
	pHexFile = fopen(argv[--argc], "wb");
	if (!pHexFile) 
	{
		printf("Cannot open %s for writing.\n", argv[argc]);
		return -1;
	}
	pBMPFile = fopen(argv[--argc], "rb");
	if (!pBMPFile) 
	{
		printf("Cannot open %s for reading.\n", argv[argc]);
		return -1;
	}
	if (argc == 2 && strcmp(argv[--argc], "-f") == 0)
	{
		bFlipped = 1;
	}
	else
	{
		bFlipped = 0;
	}
	// Read the bitmap headers.
	ReadFileHeader(&bmfh, pBMPFile);
	ReadInfoHeader(&bmih, pBMPFile);
	switch (bmih.biCompression)
	{
	case BI_RGB:
		if (bmih.biBitCount == 24)
		{
			ConvertRGB(pBMPFile, pHexFile, &bmih, bFlipped);
			break;
		}
		else
		{
			printf("Sorry, this program requires that the bit count be 24.\n");
			return -1;
		}
	case BI_RLE8:
	case BI_RLE4:
		printf("Sorry, this program does not work with compressed bitmaps.\n");
		return -1;
	default:
		printf("What kind of compression is this?\n");
		return -1;
	}
	printf("yeah!\n");
	// Close files.
	fclose(pHexFile);
	fclose(pBMPFile);
	return 0;
}

void Help()
{
	printf("bmp2hex v2.1: converts Windows bitmap files into the hex format so we can store it in RAM.\n");
	printf("syntax: bmp2hex [-f/-u] <BMP file name> <HEX file name>\n");
	printf("-f/-u (optional): flipped or upright (default is upright)\n");
	printf("Right now the bitmap must be in uncompressed 24-bit RGB format.\n");
}

/*
 * Read the bitmap file header.
 */
void ReadFileHeader(BITMAPFILEHEADER *pBmfh, FILE *pBMPFile)
{
	fread(&pBmfh->bfType, sizeof(pBmfh->bfType), 1, pBMPFile);
	fread(&pBmfh->bfSize, sizeof(pBmfh->bfSize), 1, pBMPFile);
	fread(&pBmfh->bfReserved1, sizeof(pBmfh->bfReserved1), 1, pBMPFile);
	fread(&pBmfh->bfReserved2, sizeof(pBmfh->bfReserved2), 1, pBMPFile);
	fread(&pBmfh->bfOffBits, sizeof(pBmfh->bfOffBits), 1, pBMPFile);	
}

/*
 * Read the bitmap information header.
 */
void ReadInfoHeader(BITMAPINFOHEADER *pBmih, FILE *pBMPFile)
{
	fread(&pBmih->biSize, sizeof(pBmih->biSize), 1, pBMPFile);
	fread(&pBmih->biWidth, sizeof(pBmih->biWidth), 1, pBMPFile);
	fread(&pBmih->biHeight, sizeof(pBmih->biHeight), 1, pBMPFile);
	fread(&pBmih->biPlanes, sizeof(pBmih->biPlanes), 1, pBMPFile);
	fread(&pBmih->biBitCount, sizeof(pBmih->biBitCount), 1, pBMPFile);
	fread(&pBmih->biCompression, sizeof(pBmih->biCompression), 1, pBMPFile);
	fread(&pBmih->biSizeImage, sizeof(pBmih->biSizeImage), 1, pBMPFile);
	fread(&pBmih->biXPelsPerMeter, sizeof(pBmih->biXPelsPerMeter), 1, pBMPFile);
	fread(&pBmih->biYPelsPerMeter, sizeof(pBmih->biYPelsPerMeter), 1, pBMPFile);
	fread(&pBmih->biClrUsed, sizeof(pBmih->biClrUsed), 1, pBMPFile);
	fread(&pBmih->biClrImportant, sizeof(pBmih->biClrImportant), 1, pBMPFile);
}

void ConvertRGB(FILE *pBMPFile, FILE *pHexFile, BITMAPINFOHEADER *pBmih, unsigned char bFlipped)
{
	unsigned short address;
	long i, j, bytesRead, pixelsExpected, bytesExpected;
	long rowWidth;
	long bytesInRow, rowSize;
	unsigned char code;
	bgr_type *pBitmap;
	unsigned char checksum;
	address = 0;
	unsigned char *pJunk;

	/* Sometimes the bit files has extra bytes at the end of the row.  We read them into
	   pJunk and ignore them.*/
	rowWidth = pBmih->biSizeImage/pBmih->biHeight;
	if (rowWidth > 3*pBmih->biWidth)
		pJunk = new unsigned char[rowWidth - 3*pBmih->biWidth];
	else
		pJunk = NULL;
	pixelsExpected = pBmih->biWidth * pBmih->biHeight;
	bytesExpected = 3 * pixelsExpected;
	pBitmap = new bgr_type[pixelsExpected];
	bytesRead = 0;
	for (i = 0; i < (long) pBmih->biSizeImage; i += rowWidth)
	{
		bytesRead += 3*fread(pBitmap + bytesRead/3, 3, pBmih->biWidth, pBMPFile);
		if (pJunk) fread(pJunk, 1, rowWidth - 3*pBmih->biWidth, pBMPFile);
	}
	int error = ferror(pBMPFile);
	if (bytesRead != (long) bytesExpected)
	{
		printf("Failed to read expected number of pixels.  Please contact customer support.\n");
		printf("expected %d on %d and %d\n", bytesExpected, pBmih->biWidth, pBmih->biHeight);
		printf("read %d\n", bytesRead);
		return;
	}
	if (bFlipped)
	{
		for (i = 0; i < pixelsExpected; i += pBmih->biWidth)
		{
			bytesInRow = 0;
			while (bytesInRow < pBmih->biWidth)
			{
				rowSize = MIN(MAX_FROW, pBmih->biWidth - bytesInRow);
				checksum = rowSize + ((char) (address >> 8)) + ((char) (address & 0x00FF));
				fprintf(pHexFile, ":%.2x%.4x00", rowSize);
				for (j = 0; j < rowSize; j++)
				{
					code = (pBitmap[i+j].red << 4) + (pBitmap[i+j].green << 2) + pBitmap[i+j].blue;
					checksum += code;
					fprintf(pHexFile, "%.2x", code);
				}
				checksum = 0xFF - checksum + 1;
				fprintf(pHexFile, "%.2x\r\n", checksum);
				bytesInRow += rowSize;
				address += (unsigned short) rowSize;
			}
		}
	}
	else // upright
	{
		for (i = pixelsExpected - pBmih->biWidth; i >= 0; i-= pBmih->biWidth)
		{
			bytesInRow = 0;
			while (bytesInRow < pBmih->biWidth)
			{
				rowSize = MIN(MAX_FROW, pBmih->biWidth - bytesInRow);
				fprintf(pHexFile, ":%.2x%.4x00", rowSize, address);
				checksum = rowSize + ((char) (address >> 8)) + ((char) (address & 0x00FF));
				for (j = bytesInRow; j < bytesInRow + rowSize; j ++)
				{
					code = ((pBitmap[i+j].red/0x40) << 4) + ((pBitmap[i+j].green/0x40) << 2)
						+ (pBitmap[i+j].blue/0x40);
					checksum += code;
					fprintf(pHexFile, "%.2x", code);
				}
				checksum = 0xFF - checksum + 1;
				fprintf(pHexFile, "%.2x\r\n", checksum);
				bytesInRow += rowSize;
				address += (unsigned short) rowSize;
			}
		}		
	}
	delete pBitmap;
	// checksum = 2's complement of sum of high two bytes of address and low two bytes of address
	// and 1 (EOF byte) = 0xFF - (address high + address low + 1) + 1 =
	// 0xFF - (address high + address low)
	checksum = 0xFF - (((char) (address >> 8)) + ((char) (address & 0x00FF)));
	fprintf(pHexFile, ":00%.4x01%.2x\r\n", address, checksum);
}