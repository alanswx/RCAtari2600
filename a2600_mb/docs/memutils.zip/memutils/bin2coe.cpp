/*
 * bin2coe.cpp
 * -----------
 * Converts a binary file to the COE format so you can use it to initialize
 * COREGen memory.
 */

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>

void Help();
int ConvertBin(FILE *pBinFile, FILE *pCoeFile, unsigned int numbits, char littleEndian);
void ToBigEndian(unsigned char *pBin, unsigned int len, unsigned int numbits);

// the default memory width is 8
#define DEFAULT_NUM_BITS 8
// the default format is Little Endian
#define DEFAULT_LITTLE_ENDIAN 1

int main(int argc, char* argv[])
{
	FILE *pBinFile, *pCoeFile;
	unsigned int numbits;
	int arg, success;
	char littleEndian;

	// Parse command-line arguments.
	// See the the usage guide for an explanation of the command line arguments.
	if (argc == 1 || argc > 8) {
		Help();
		return -1;
	}
	numbits = DEFAULT_NUM_BITS;
	littleEndian = DEFAULT_LITTLE_ENDIAN;
	pBinFile = pCoeFile = 0;
	arg = 1;
	while (arg < argc) {
		if (strcmp(argv[arg],"-i")==0) {
			pBinFile = fopen(argv[++arg], "rb");
			if (!pBinFile) 
			{
				fprintf(stderr, "Cannot open binary file %s for reading.\n", argv[arg]);
				Help();
				return -1;
			}					
		}
		else if (strcmp(argv[arg], "-o")==0) {
			pCoeFile = fopen(argv[++arg], "wb");
			if (!pCoeFile) 
			{
				fprintf(stderr, "Cannot open COE file %s for writing.\n", argv[++arg]);
				Help();
				return -1;
			}
		}
		else if (strcmp(argv[arg], "-b")==0) {
			littleEndian = 0;
		}
		else if (strcmp(argv[arg], "-n")==0) {
			numbits = atoi(argv[++arg]);
			if (numbits > 32) {
				fprintf(stderr, "Sorry, you must have between 1 and 32 bits per sample.\n");
				return -1;
			}
		}
		else
		{
			fprintf(stderr, "Unrecognized flag %s\n", argv[arg]);
			Help();
			return -1;
		}
		++arg;
	}
	if (pBinFile == 0 || pCoeFile == 0) {
		fprintf(stderr, "You must specify input and output files.\n");
		Help();
		return -1;
	}

	success = ConvertBin(pBinFile, pCoeFile, numbits, littleEndian);
	if (success) printf("yup!\n");
	// Close files.
	fclose(pCoeFile);
	fclose(pBinFile);
	return 0;
}

// usage information to be displayed after command-line syntax errors
void Help()
{
	printf("syntax: bin2coe [-n <bits per sample>] [-b] [-i <binary file name>] [-o <COE file name>]\n");
}

// convert the binary file to COE
int ConvertBin(FILE *pBinFile, FILE *pCoeFile, unsigned int numbits, char littleEndian)
{
	long bytesRead;
	unsigned char *pBin;
	unsigned int numbytes, numhex;
	// number of bytes per memory location
	numbytes = (unsigned int) ceil((double)numbits/8);
	// number of of hexadecimal characters needed to represent each element stored in memory
	numhex = (unsigned int) ceil((double)numbits/4);

	// display the COE header
	fprintf(pCoeFile, "MEMORY_INITIALIZATION_RADIX=16;\r\n");
	fprintf(pCoeFile, "MEMORY_INITIALIZATION_VECTOR=");
	pBin = new unsigned char[4];
	while ((bytesRead = fread(pBin, 1, numbytes, pBinFile)) != 0)
	{
		// Convert the data to Little Endian (despite the misleading function name).
		if (!littleEndian) ToBigEndian(pBin, bytesRead, numbytes);
		switch(numhex) {
		case 1: fprintf(pCoeFile, "\r\n%.1x,", *((unsigned char *)pBin)); break;
		case 2: fprintf(pCoeFile, "\r\n%.2x,", *((unsigned char *)pBin)); break;
		case 3: fprintf(pCoeFile, "\r\n%.3x,", *((unsigned short *)pBin)); break;
		case 4: fprintf(pCoeFile, "\r\n%.4x,", *((unsigned short *)pBin)); break;
		case 5: fprintf(pCoeFile, "\r\n%.5x,", *((unsigned long *)pBin)); break;
		case 6: fprintf(pCoeFile, "\r\n%.6x,", *((unsigned long *)pBin)); break;
		case 7: fprintf(pCoeFile, "\r\n%.7x,", *((unsigned long *)pBin)); break;
		case 8: fprintf(pCoeFile, "\r\n%.8x,", *((unsigned long *)pBin)); break;
		default: fprintf(stderr, "Unexpected value of numhex = %d\n", numhex); return 0;
		}
	}
	ungetc(',', pCoeFile);
	fprintf(pCoeFile, ";\r\n");
	delete pBin;
	return 1;
}

// Switch the endian-ness of a data buffer.  Despite the name, this could just as easily
// be a big-to-little endian converter as a little-to-big endian converter.
// LEsize is the number of bytes in each memory element.
void ToBigEndian(unsigned char *pBin, unsigned int len, unsigned int LESize)
{
	unsigned int i;
	unsigned char temp;

	if (LESize == 1) return;
	if ((len % LESize) != 0) {
		fprintf(stderr, "Error: Length of array of binary data is not a multiple of %d\n", LESize);
		fprintf(stderr, "I'm not going to put up with that!\n");
		return;
	}
	for (i = 0; i < len; i+=LESize) {
		switch (LESize) {
		case 2:
			temp = pBin[i];
			pBin[i] = pBin[i+1];
			pBin[i+1] = temp;
			break;
		case 4:
			temp = pBin[i];
			pBin[i] = pBin[i+3];
			pBin[i+3] = temp;
			temp = pBin[i+1];
			pBin[i+1] = pBin[i+2];
			pBin[i+2] = temp;
			break;
		default:
			fprintf(stderr, "I expected a LESize of 2 or 4, not %d.\n", LESize);
			return;
		}
	}
}